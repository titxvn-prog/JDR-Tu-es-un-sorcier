---
PE: -3 PE
Prérequis: Aucun
Description: "Vous êtes un monstre dans un domaine précis. Choisissez une compétence : +2 dans cette compétence et relance possible 1 fois par séance."
---
