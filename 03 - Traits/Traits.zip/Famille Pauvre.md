---
PE: +1 PE
Prérequis: Ne pas avoir Famille Riche
Description: Votre coffre à Gringotts contient quelques toiles d'araignée. Vous gagnez 1 point de richesse.
---
