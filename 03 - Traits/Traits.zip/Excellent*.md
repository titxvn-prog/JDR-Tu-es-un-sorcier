---
PE: -2 PE
Prérequis: Avoir le trait Bon
Description: Vous êtes excellent dans une matière. Bénéficiez d'un +4 dans une matière.
---
