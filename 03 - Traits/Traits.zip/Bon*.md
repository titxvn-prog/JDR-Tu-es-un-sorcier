---
PE: -1 PE
Prérequis: Aucun
Description: Vous êtes bon dans une matière. Bénéficiez d'un +2 dans une matière.
---
