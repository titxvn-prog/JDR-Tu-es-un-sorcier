---
PE: -1 PE
Prérequis: Aucun
Description: " Vous comprenez naturellement les bêtes. Vos interactions avec les créatures sont avantagés."
---
