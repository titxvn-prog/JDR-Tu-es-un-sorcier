---
PE: -1 PE
Prérequis: Aucun
Description: Vous représentez parfaitement les valeurs de votre Maison. Choisissez une valeur et respectez la pour bénéficier d'une deuxième action de Maison par séance.
---
