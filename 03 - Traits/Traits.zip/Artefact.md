---
PE: -1 PE
Prérequis: Aucun
Description: Votre famille hérite d'un objet transmis de génération en génération. Tirez un artefact.
---
