---
PE: +1 PE
Prérequis: Aucun
Description: Sans vos lunettes, vous voyez moins bien que votre hibou. Si vous perdez vos lunettes, votre Perception tombe à 0.
---
