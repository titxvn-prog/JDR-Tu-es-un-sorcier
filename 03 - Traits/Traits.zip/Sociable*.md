---
PE: -1 PE
Prérequis: Aucun
Description: Vous adorez vous faire de nouveaux amis. Vous gagnez une carte amitié en plus.
---
