---
PE: -1 PE
Prérequis: Aucun
Description: Ton esprit de leader galvanise les troupes. Une fois par match, tu offres +1 à tous les membres de ton équipe pendant un round de jeu.
---
