---
PE: -1 PE
Prérequis: Aucun
Description: Votre famille fait parti de la noblesse. Vous êtes respectez dans le monde des sorciers.
---
