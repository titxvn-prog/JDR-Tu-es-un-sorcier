---
PE: +1 PE
Prérequis: Aucun
Description: Frapper d’abord, réfléchir ensuite. Vous devez réussir un jet d’Esprit pour ne pas agir impulsivement dans les situations tendues.
---
