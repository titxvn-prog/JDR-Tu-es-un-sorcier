---
PE: +1 PE
Prérequis: Ne pas avoir Bon
Description: Vous êtes nul dans une matière. Enlevez -2 dans une matière.
---
