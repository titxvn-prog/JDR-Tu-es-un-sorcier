---
PE: +1 PE
Prérequis: Aucun
Description: Vous n'aimez pas trop vous imposez. Vous agissez toujours en dernier.
---
