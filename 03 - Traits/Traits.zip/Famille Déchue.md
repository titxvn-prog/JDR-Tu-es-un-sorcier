---
PE: +1 PE
Prérequis: Aucun
Description: La réputation de votre famille a été entaché par le passé. Les sorciers vous méprisent.
---
