---
PE: -1 PE
Prérequis: Aucun
Description: Vous aimez qu'on vous remarque. Vous gagnez +1 lors d'un jet contenant le Coeur.
---
