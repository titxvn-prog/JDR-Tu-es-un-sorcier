---
PE: +1 PE
Prérequis: Aucun
Description: Vous développez une peur bleu. Enlevez -2 à tous vos jets quand vous êtes face à cette phobie.
---
