---
PE: +1 PE
Prérequis: Aucun
Description: Vous passez toujours inaperçu, même quand vous ne le voulez pas. Faites un jet Esprit + Endurance pour vous imposer dans une discussion.
---
