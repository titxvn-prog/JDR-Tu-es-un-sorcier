---
PE: +1 PE
Prérequis: Aucun
Description: Il vaut mieux pas ne vous irritez. Vous êtes incapable de lancer un sort de défense.
---
