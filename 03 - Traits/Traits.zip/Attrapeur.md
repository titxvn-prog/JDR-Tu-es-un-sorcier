---
PE: -2 PE
Prérequis: Aucun
Description: Tu n'as d'yeux que pour le  Vif d'Or. +2 pour repérer ou attraper le Vif d'Or et une fois par match, tu peux ignorer un échec lié à sa poursuite.
---
