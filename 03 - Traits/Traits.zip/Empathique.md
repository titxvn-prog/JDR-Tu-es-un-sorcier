---
PE: -1 PE
Prérequis: Aucun
Description: Vous captez les émotions comme un radar émotionnel. Pour détecter un mensonge, faites un jet de Bluff et ajouter la Perception, et pour lire les émotions, faites un jet de Perception et ajouter la Romance.
---
