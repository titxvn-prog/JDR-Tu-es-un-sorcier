---
PE: -1 PE
Prérequis: Ne pas avoir Famille Pauvre
Description: Votre coffre à Gringotts brille de mille feu. Vous gagnez 1 point de richesse.
---
