---
PE: -1 PE
Prérequis: Aucun
Description: Vous avez un familier spéciale qui vous accompagnera durant votre scolarité. Piochez un familier spécial.
---
