---
PE: +1 PE
Prérequis: Aucun
Description: Vos ancêtres ne vous veulent pas du bien. Une fois par séance, le Directeur peut vous demander de relancer un jet réussi.
---
