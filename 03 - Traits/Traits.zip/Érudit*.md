---
PE: -1 PE
Prérequis: Aucun
Description: Vous aimez les bibliothèque et les livres. Vous gagnez un point d'érudition en plus.
---
