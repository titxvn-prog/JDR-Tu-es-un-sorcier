---
PE: \+ ou -1PE
Prérequis: Aucun
Description: Vous êtes connu dans le monde des sorciers. Vous attirez ou faites fuir les foules.
---
