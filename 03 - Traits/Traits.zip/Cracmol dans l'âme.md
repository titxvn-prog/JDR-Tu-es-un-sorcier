---
PE: +1 PE
Prérequis: Aucun
Description: Vous avez beau être sorcier… la magie vous évite. Une fois par séance, un sort que vous lancez ne fonctionne tout simplement pas.
---
