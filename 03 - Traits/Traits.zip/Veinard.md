---
PE: -1 PE
Prérequis: Aucun
Description: Vous ne trouvez plus que des trèfles à 4 feuilles. Vos réussites critiques surviennent désormais sur un 19 ou un 20.
---
