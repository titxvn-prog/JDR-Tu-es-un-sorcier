---
PE: -3 PE
Prérequis: Avoir le trait Excellent
Description: Vous êtes un génie dans une matière. Bénéficiez d'un +6 dans une matière.
---
