---
PE: -1 PE
Prérequis: Aucun
Description: Vous avez un grand frère ou une grande sœur à Poudlard. Il pourra vous venir en aide
---
