---
PE: -2 PE
Prérequis: Aucun
Description: Vous pouvez parler aux serpents. Vous pouvez comprendre et communiquer avec les serpents ; bonus d’interaction avec les créatures reptiliennes.
---
