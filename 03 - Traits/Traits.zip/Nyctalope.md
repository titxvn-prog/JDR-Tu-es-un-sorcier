---
PE: -1 PE
Prérequis: Aucun
Description: Vous avez des yeux qui transpercent le noir. Vous voyez dans le noir.
---
