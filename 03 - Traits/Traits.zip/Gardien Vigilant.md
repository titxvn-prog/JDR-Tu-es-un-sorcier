---
PE: -1 PE
Prérequis: Aucun
Description: Tu ne laisses passer aucun Souafle. Une fois par match, tu peux bloquer un but automatiquement si tu as anticipé correctement.
---
