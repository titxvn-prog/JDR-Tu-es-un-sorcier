---
PE: +1 PE
Prérequis: Être en deuxième année
Description: Vous avez un petit frère ou une petite soeur à Poudlard. Vous devrez l'aider si besoin
---
