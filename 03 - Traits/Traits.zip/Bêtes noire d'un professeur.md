---
PE: +1 PE
Prérequis: Aucun
Description: D'après le professeur, tout est de votre faute. Vous subirez des punitions, des mauvaises notes ou perdrez des points de Maison à cause du professeur.
---
