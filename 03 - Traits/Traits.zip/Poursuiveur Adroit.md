---
PE: -1 PE
Prérequis: Aucun
Description: Tu passes le Souafle aussi facilement qu’on souffle une plume. +2 à tes passes et tirs avec le Souafle, et tu ne rates jamais une réception sauf échec critique.
---
