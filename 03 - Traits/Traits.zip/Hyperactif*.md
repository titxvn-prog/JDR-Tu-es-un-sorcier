---
PE: -1 PE
Prérequis: Aucun
Description: Vous fatiguez plus les autres que vous même. Vous gagnez un point d'énergie en plus.
---
