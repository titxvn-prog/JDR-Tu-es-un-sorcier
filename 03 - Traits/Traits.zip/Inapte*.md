---
PE: +1 PE
Prérequis: Aucun
Description: Même avec tout l'entrainement du monde vous ne serez pas meilleur qu'un caillou. Choisissez une compétence et ratez automatique tous vos jets la concernant.
---
