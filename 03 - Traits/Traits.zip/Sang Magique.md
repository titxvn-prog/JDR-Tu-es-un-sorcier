---
PE: -4 PE
Prérequis: Aucun
Description: Vous n'êtes pas tout à fait humain. Choisissez un sang magique.
---
