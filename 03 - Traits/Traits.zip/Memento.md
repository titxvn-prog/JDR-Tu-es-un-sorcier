---
PE: +3 PE
Prérequis: Aucun
Description: Votre mémoire est défaillante. Une fois par séance, vous oubliez un sort, un ami, un objectif de quête jusqu'à ce que vous le réappreniez.
---
