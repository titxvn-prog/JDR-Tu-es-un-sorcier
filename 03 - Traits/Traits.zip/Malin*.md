---
PE: -1 PE
Prérequis: Aucun
Description: Vous êtes plus intelligent que la moyenne. Vous gagnez +1 lors d'un jet contenant l'Esprit.
---
