---
PE: -1 PE
Prérequis: Aucun
Description: Vous ne passez pas un jour sans faire du sport. Vous gagnez +1 lors d'un jet contenant le Corps.
---
