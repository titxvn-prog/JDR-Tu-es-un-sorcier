---
PE: -3 PE
Prérequis: Aucun
Description: Les paroles que vous dites font sens chez les autres. Vous ajoutez +2 lors de l'utilisation des compétences de Bluff, de Persuasion, de Romance et de Rumeur.
---
