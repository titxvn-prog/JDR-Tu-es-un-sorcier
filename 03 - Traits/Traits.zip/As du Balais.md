---
PE: -2 PE
Prérequis: Aucun
Description: Vous avez un don pour manier le balais. Montez d'un cran votre niveau de Vol
---
