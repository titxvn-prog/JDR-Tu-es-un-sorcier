---
PE: -1 PE
Prérequis: Avoir famille riche
Description: Votre famille est assez aisé pour se permettre d'avoir un serviteur. Vous pouvez lui demander un service une fois par séance.
---
