---
PE: -1 PE
Prérequis: Aucun
Description: Vous réfléchissez… après avoir agi. Vous gagnez +2 à toute action entreprise sans concertation ou plan préalable.
---
