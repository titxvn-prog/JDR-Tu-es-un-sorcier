---
PE: -2 PE
Prérequis: Avoir un autre PJ volontaire
Description: Vous partagez un lien unique avec un autre élève. Une fois par séance, vous pouvez ressentir ses émotions ou lui parler mentalement mais si vous partagez aussi les Conséquences.
---
