---
PE: -1 PE
Prérequis: Aucun
Description: Tout le monde vous comprend lorsque vous expliquez quelques choses. Vous pouvez aider un plus grand groupe de personne.
---
