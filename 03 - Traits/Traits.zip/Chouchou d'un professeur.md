---
PE: -1 PE
Prérequis: Aucun
Description: Le professeur vous adore. Vous faites gagnez des points de Maison sans vraiment de raison valable avec ce professeur.
---
