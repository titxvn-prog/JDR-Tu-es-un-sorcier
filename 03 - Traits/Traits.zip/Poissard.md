---
PE: +1 PE
Prérequis: Aucun
Description: es trèfles à 4 feuilles perdent un pétale par prudence en vous voyant. Vos échecs critiques surviennent désormais sur un résultat sur un 1 ou un 2.
---
