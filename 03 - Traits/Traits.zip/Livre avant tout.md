---
PE: -3 PE
Prérequis: Ne pas avoir Sociable
Description: Vous avez passé votre enfance à être plonger dans les bouquins. Vous êtes excellent dans toutes les matières mais ne bénéficiez pas de carte amitié et -2 sur tous vos jets sociaux.
---
