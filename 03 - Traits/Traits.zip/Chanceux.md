---
PE: -1 PE
Prérequis: Aucun
Description: La chance vous souris. Une fois par séance, vous pouvez décidé de relancer un jet raté.
---
