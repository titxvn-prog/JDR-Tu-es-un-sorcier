---
PE: -1 PE
Prérequis: Aucun
Description: Cognards ou pas, tu vises toujours juste. +2 pour viser un Cognard et le diriger où tu veux (adversaire, trajectoire, défense).
---
