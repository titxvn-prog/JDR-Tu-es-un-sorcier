---
PE: -1 PE
Prérequis: Aucun
Description: Vous balancez entre 2 maisons. Choisissez 2 maisons au lieu d'une.
---
